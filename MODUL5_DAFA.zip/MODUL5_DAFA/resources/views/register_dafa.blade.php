<?php
    require 'config/connect2_dafa.php';
    if(isset($_POST["submit"])){
        $name = $_POST["nama"];
        $email = $_POST["email"];
        $phone = $_POST["no_hp"];
        $pw = $_POST["password"];
        $pw_confirm = $_POST["password_konfirmasi"];
        $duplicate = mysqli_query($conn, "SELECT * FROM user_dafa WHERE email = '$email'");
        if(mysqli_num_rows($duplicate) > 0){
            echo
            "<script> alert('Email has already taken'); </script>";
        }
        else{
            if($pw == $pw_confirm){
                $query = "INSERT INTO user_dafa VALUES('$name', '$email', '$phone', '$pw', '$pw_confirm')";
                mysqli_query($conn, $query);
                echo
                "<script> alert('Registration Succesful')";
            }
        }
    }
    ?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <?php if(isset($_COOKIE['nav'])) {
        if($_COOKIE['nav'] == 'blue') { ?>
        <style>
            .header { 
                background-color: blue;
            }
            .footer {
                background-color: blue;
            }
        </style>
    <?php } } ?>

    <?php if(isset($_COOKIE['nav'])) {
        if($_COOKIE['nav'] == 'yellow') { ?>
        <style>
            .header {
                background-color: yellow;
            }
            .footer {
                background-color: yellow;
            }
        </style>
    <?php } } ?>

    <?php if(isset($_COOKIE['nav'])) {
        if($_COOKIE['nav'] == 'red') { ?>
        <style>
            .footer {
                background-color: red;
            }
            .header {
                background-color: red;
            }
        </style>
    <?php } } ?>
    

    <title>Dafa's Showroom</title>
</head>

<body>
    <div class="header">
        <div class="row">
            <div class="col" style="margin-top: 10px; margin-left: 100px;">
                <a href="index.php"><span class="text text-white">Dafa's Showroom</span></a>
            </div>
            <div class="col">
                <div class="position-relative" style="margin-left: 70%; margin-top: 10px;">
                    <a href="register_dafa.php" class="text text-white" style="margin-right: 10px;">Register</a>
                    <a href="login_dafa.php" class="text text-white">Login</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <div class="col-4">
                <form method="post" action="">
                <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Masukan Nama Lengkap" name="nama">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Masukan Alamat E-mail" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Nomor Handphone</label>
                        <input type="text" class="form-control" id="exampleInputPassword1"
                            placeholder="Masukan Nomor Handphone" name="no_hp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Kata Sandi</label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Kata Sandi Anda" name="password">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Konfirmasi Kata Sandi</label>
                        <input type="password" class="form-control" id="password_konfirmasi" name="password_konfirmasi"
                            placeholder="Konfirmasi Kata Sandi Anda">
                    </div>
                    <button type="submit" class="btn btn-primary" id="btn_submit" disabled name="submit">Daftar</button>
                    <br>
                    <label class="form-check-label" for="exampleCheck1">Anda sudah punya akun? <a
                            href="login_dafa.php">Login</a></label>
                </form>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="row">
            <div class="col" style="text-align: center; margin-top: 10px;">
                <span class="text text-white">&copy;2022 Copyright: <a href="#" data-bs-toggle="modal" data-bs-target="#nimModal">DAFA ANDIKA 1202204206</a></span>
            </div>
        </div>
    </div>

    <div class="modal fade" id="nimModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Created By</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            Nama: Dafa Andika
            <br>
            NIM: 1202204206
          </div>
        </div>
      </div>
    </div>

    
</body>

</html>