<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "wad_modul4_dafaandika");
?>