<?php
    $connect = new mysqli("localhost:8080", "root", "", "wad_modul4_dafaandika", 3306);

    if(!$connect){
        die("<p>Not Connected</p>"
        mysqli_connect_error());
    }
?>